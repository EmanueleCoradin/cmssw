from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test0_mc_leptons_0_DYto2L2Jets'
config.section_('JobType')
config.JobType.psetName = 'forest_miniAOD_run3_MC_leptons.py'
config.JobType.maxJobRuntimeMin = 1200
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.publication = False
config.Data.inputDataset = '/DYto2L-2Jets_MLL-50_TuneCP5_5p36TeV_amcatnloFXFX-pythia8/HINPbPbSpring23MiniAOD-132X_mcRun3_2023_realistic_HI_v9-v3/MINIAODSIM'
config.Data.outputDatasetTag = 'CRAB3_test0_mc_leptons_0_DYto2L2Jets'
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
